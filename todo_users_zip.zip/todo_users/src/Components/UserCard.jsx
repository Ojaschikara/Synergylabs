import{Box,Heading,useToast ,Button,Stack,Text,StackDivider, Card, CardHeader, CardBody, CardFooter, HStack } from "@chakra-ui/react"

import { useParams , useNavigate } from "react-router-dom"
import { useState,useEffect } from "react";
import axios from "axios";

export default function UserInfo(){
    
    const[user,setUsers]=useState({})
    const toast=useToast()
    const {id} =useParams()
    
    const navigate=useNavigate()
   
    async function fetchAndUpdateData(id){
        
        try {
            let res= await axios({
                method:"get",
                url:`https://jsonplaceholder.typicode.com/users/${id}`,
            });
           

            let data=res?.data;
            setUsers(data);
        } catch (error) {
          
            console.log("error fetch",error)
        }
    }

    useEffect(()=>{
        fetchAndUpdateData(id)
    },[id])
   
    // console.log("loading",loading,"err-",err)
    // console.log("tickets",tickets)

  

     async function handleDelete(id){
       try {
        let res=await axios.delete(`https://jsonplaceholder.typicode.com/users/${id}`)
        console.log("user res",res.data)
        if(res.status===200){
          toast({
            title: 'User Deleted..!',
            description: "User Section",
            status: 'success',
            duration: 2000,
            isClosable: false,
            colorScheme:"red"
          })
            navigate("/user")
            console.log("user navigate res",res)
        }
       } catch (error) {
        console.log(error)
       }   
    }
    const{name,email,phone}=user;

    return(
        <Card>
        <CardHeader>
          <Heading size='md'>User Info</Heading>
        </CardHeader>
      
        <CardBody>
          <Stack divider={<StackDivider />} spacing='4'>
          
            <Box>
              <Heading size='xs' textTransform='uppercase'>
                Name:
              </Heading>
              <Text pt='2' fontSize='sm'>
              {name}      </Text>
            </Box>
            <Box>
              <Heading size='xs' textTransform='uppercase'>
                Email:
              </Heading>
              <Text pt='2' fontSize='sm'>
              {email}      </Text>
            </Box>
            <Box>
              <Heading size='xs' textTransform='uppercase'>
               Phone No.:
              </Heading>
              <Text pt='2' fontSize='sm'>
                {phone}
              </Text>
            </Box>
           
          </Stack>
        </CardBody>
        <CardFooter>
          <HStack spacing={5}>
          <Button variant='outline' colorScheme='red' onClick={()=>{navigate(`/user/edit/${id}`)}}>
             Edit Ticket
            </Button>
            <Button variant='outline' colorScheme='red' onClick={handleDelete}>
             Delete Ticket
            </Button>
          </HStack>
           
            </CardFooter>
      </Card>
    )
}