import{ Box, Heading, TableContainer,Table,Thead,Tr,Td,Th,Tbody,Button} from "@chakra-ui/react"
import { useNavigate } from "react-router-dom"
import { useEffect, useState } from "react";
import UserCard from "../Components/UserCard";
import axios from "axios";

export default function TodoPage(){
    const[users,setUsers] = useState([]);
   const navigate=useNavigate();
   function HandleClick(){
    navigate("/")
   }
   function HandleAddUser(){
    navigate("/user/adduser")
   }

   useEffect(()=>{
    const fetchUsers=async()=>{
        try {
            let res= await axios({
                method:"get",
                url:"https://jsonplaceholder.typicode.com/users",
               
            });
            let data=res?.data;
            setUsers(data)
        } catch (error) {
            console.log("error in fetching users data",error)
        }
    }
    fetchUsers()
},[]);
   
   
    return(
//         <>
//         <Box>
//     <Heading as="h1" size="xl" textAlign="center" >TODO USER</Heading>
//     <Button colorScheme="blue" variant="outline" onClick={HandleClick}  >
//       Go to Home
//      </Button>
//    </Box>
   
  
//      {/* {users?.map((user)=> (
//     <UserCard {...user} key={user.id} />

//    ))} */}
//       <div >
   
      
//         {/* <TableContainer textAlign="center"> */}
//             <Table size="lg"  >
//             <Thead>
//       <Tr>
//         <Th>Name</Th>
//         <Th>Email</Th>
//         <Th  >Phone No.</Th>
//         <Th>Get User</Th>
//         </Tr>
//     </Thead>
//             </Table>
//         {/* </TableContainer > */}
//         {users.map(user => (
//           <div key={user.id} >
//             {/* {user.name} {user.email} */}
//             {/* <TableContainer> */}
//   <Table size='sm' textAlign="center" >
   
//     <Tbody >
//       <Tr  >
//         <Td>{user.name}</Td>
//         <Td >{user.email}</Td>
//         <Td >{user.phone}</Td>
//         <Td>
//         <Button  variant='outline' colorScheme='red' onClick={()=>{navigate(`/user/${user.id}`)}}>
//         Get User
//       </Button>
//         </Td>
//       </Tr>
     
//     </Tbody>
   
//   </Table>
// {/* </TableContainer> */}
//           </div>
//         ))}
      
//     </div>
//    </>
<>
<div>
<Box>
     <Heading as="h1" size="xl" textAlign="center" >TODO USER</Heading>
 <Button colorScheme="blue" variant="outline" onClick={HandleClick}  >
      Go to Home
</Button>
<Button colorScheme="blue" variant="outline" onClick={HandleAddUser}  >
     Add User
</Button>
   </Box>
      <h1>Todo List</h1>
      <table>
                <thead>
                    <tr>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Phone</td>
                        <td>Get User</td>
                    </tr>
                </thead>
                <tbody>
                
        {users.map(user => (
          <tr key={user.id}>
           
            
                        <td> {user.name} </td>
                        <td>{user.email}</td>
                        <td>{user.phone}</td>
                        <td><Button  variant='outline' colorScheme='red' onClick={()=>{navigate(`/user/${user.id}`)}}>
         Get User
       </Button></td>
                    </tr>
            
         
        ))}
      
                   
                </tbody>
            </table>
     
    </div>
</>
   
    )
    
}