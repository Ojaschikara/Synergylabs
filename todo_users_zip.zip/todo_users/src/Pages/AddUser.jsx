
import { Button,useToast, Container,Input,Select,Textarea,VStack } from "@chakra-ui/react"
import axios from "axios";
import { useState } from "react"
import { useNavigate } from "react-router-dom";
export default function AddUser(){
    const[name,setName]=useState("");
    const[email,setEmail]=useState("")
    const[phone,setPhone]=useState("")
    const navigate=useNavigate()
    const toast=useToast()
    async function handleAddUser(){
        try {
        
        const newUser={
            id:Math.random(),
            name:name,
            email:email,
            phone:phone,
        };
         let res=await axios({
            method:"post",
            url:"https://jsonplaceholder.typicode.com/users",
            data:newUser,
           
         });
        //  console.log(res)
         if(res.status===201){
            toast({
                title: 'User added succcessfully!',
                description: "Navigated to Tickets section",
                status: 'success',
                duration: 3000,
                isClosable: false,
              })
            navigate("/user")
         }
    } 
    catch (error) {
        console.log(error)
    }}

    return(
        <Container>
            <VStack spacing={8} my={5}>
            <Input
             placeholder="Enter Name"
             size="lg"
             value={name}
             onChange={(e)=>{
                setName(e.target.value);
             }}
              />
             <Textarea  
             placeholder="Enter email"
             size="lg"
             value = {email}
             onChange={(e)=>{
                setEmail(e.target.value);
             }}
              /> 
               <Textarea  
             placeholder="Enter phone"
             size="lg"
             value = {phone}
             onChange={(e)=>{
                setPhone(e.target.value);
             }}
              /> 
              
              <Button colorScheme="red" variant="outline" onClick={handleAddUser} >Create Ticket </Button>
            </VStack>
          
            
        </Container>
        
        
    )

    }